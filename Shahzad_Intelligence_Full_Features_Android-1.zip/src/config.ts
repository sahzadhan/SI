// Android emulator uses 10.0.2.2. For a real phone, use your computer's LAN IP.
export const API_BASE_URL = "http://10.0.2.2:3001";
